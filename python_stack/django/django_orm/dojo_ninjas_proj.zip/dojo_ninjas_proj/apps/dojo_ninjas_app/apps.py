from django.apps import AppConfig


class DojoNinjasAppConfig(AppConfig):
    name = 'dojo_ninjas_app'
