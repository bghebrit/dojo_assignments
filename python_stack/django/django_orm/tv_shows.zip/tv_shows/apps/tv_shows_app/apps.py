from django.apps import AppConfig


class TvShowsAppConfig(AppConfig):
    name = 'tv_shows_app'
