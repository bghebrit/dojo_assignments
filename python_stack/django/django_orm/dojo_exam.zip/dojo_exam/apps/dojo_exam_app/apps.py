from django.apps import AppConfig


class DojoExamAppConfig(AppConfig):
    name = 'dojo_exam_app'
