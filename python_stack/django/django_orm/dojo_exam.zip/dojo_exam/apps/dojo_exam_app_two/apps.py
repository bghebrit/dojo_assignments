from django.apps import AppConfig


class DojoExamAppTwoConfig(AppConfig):
    name = 'dojo_exam_app_two'
