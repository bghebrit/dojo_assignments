from django.db import models




class Trip(models.Model):
    destination = models.TextField()
    start_date = models.DateTimeField(auto_now_add=False)
    end_date = models.DateTimeField(auto_now_add=False)
    plan = models.CharField(max_length=255)
    users = models.ForeignKey(User,related_name="trips")
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)

# Create your models here.
