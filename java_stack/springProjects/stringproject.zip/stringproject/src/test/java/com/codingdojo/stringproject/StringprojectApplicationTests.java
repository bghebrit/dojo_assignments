package com.codingdojo.stringproject;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class StringprojectApplicationTests {

	@Test
	void contextLoads() {
	}

}
