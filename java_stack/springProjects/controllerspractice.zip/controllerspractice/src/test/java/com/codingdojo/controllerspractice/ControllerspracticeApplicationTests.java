package com.codingdojo.controllerspractice;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ControllerspracticeApplicationTests {

	@Test
	void contextLoads() {
	}

}
