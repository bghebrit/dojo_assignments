package com.codingdojo.dojoninjas;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DojoninjasApplicationTests {

	@Test
	void contextLoads() {
	}

}
